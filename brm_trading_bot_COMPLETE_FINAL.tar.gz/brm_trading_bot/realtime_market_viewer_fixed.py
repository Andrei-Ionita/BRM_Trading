"""
Real-time BRM Intraday Market Viewer - Fixed Version
Shows live market data using aiohttp WebSocket client
"""
import asyncio
import logging
import json
import aiohttp
import ssl
from datetime import datetime
from typing import Dict, Any, List
from collections import defaultdict
import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auth_working import initialize_working_auth

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


class BRMMarketViewerFixed:
    """Real-time viewer for BRM Intraday market data using aiohttp"""
    
    def __init__(self):
        """Initialize the market viewer"""
        self.auth = initialize_working_auth()
        self.websocket = None
        self.session = None
        self.running = False
        
        # Market data storage
        self.contracts = {}
        self.order_book = defaultdict(lambda: {'bids': [], 'asks': []})
        self.trades = []
        self.portfolios = []
        
        # Statistics
        self.message_count = 0
        self.last_update = None
        
        logger.info("BRM Market Viewer initialized")
    
    async def connect(self):
        """Connect to BRM Intraday WebSocket using aiohttp"""
        try:
            logger.info("🔐 Getting authentication token...")
            token_info = await self.auth.get_token_async()
            logger.info(f"✅ Token acquired, expires at {token_info.expires_at}")
            
            # Create aiohttp session
            self.session = aiohttp.ClientSession()
            
            # WebSocket URL for BRM test environment
            ws_url = "wss://intraday-pmd-api-ws-brm.test.nordpoolgroup.com/"
            
            logger.info(f"🌐 Connecting to BRM WebSocket: {ws_url}")
            
            # Create SSL context that accepts self-signed certificates
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            # Headers for authentication
            headers = {
                "Authorization": token_info.bearer_token,
                "User-Agent": "BRM-Trading-Bot/1.0",
                "Sec-WebSocket-Protocol": "v10.stomp, v11.stomp, v12.stomp"
            }
            
            # Connect to WebSocket
            self.websocket = await self.session.ws_connect(
                ws_url,
                headers=headers,
                ssl=ssl_context,
                heartbeat=30
            )
            
            logger.info("✅ WebSocket connected successfully!")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to connect to WebSocket: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return False
    
    async def send_stomp_message(self, command: str, headers: Dict[str, str] = None, body: str = ""):
        """Send a STOMP protocol message"""
        if not self.websocket:
            raise Exception("WebSocket not connected")
        
        headers = headers or {}
        
        # Build STOMP message
        message_lines = [command]
        
        for key, value in headers.items():
            message_lines.append(f"{key}:{value}")
        
        message_lines.append("")  # Empty line before body
        message_lines.append(body)
        message_lines.append("\x00")  # STOMP null terminator
        
        message = "\n".join(message_lines)
        
        logger.debug(f"Sending STOMP message: {command}")
        await self.websocket.send_str(message)
    
    async def subscribe_to_market_data(self):
        """Subscribe to all available market data streams"""
        try:
            logger.info("📊 Subscribing to market data streams...")
            
            # Subscribe to configuration (portfolios, contracts, etc.)
            await self.send_stomp_message("SUBSCRIBE", {
                "id": "config-sub",
                "destination": "/user/queue/configuration"
            })
            logger.info("   ✅ Subscribed to configuration")
            
            # Subscribe to market data (prices, volumes)
            await self.send_stomp_message("SUBSCRIBE", {
                "id": "market-sub", 
                "destination": "/topic/marketdata"
            })
            logger.info("   ✅ Subscribed to market data")
            
            # Subscribe to order book updates
            await self.send_stomp_message("SUBSCRIBE", {
                "id": "orderbook-sub",
                "destination": "/topic/orderbook"
            })
            logger.info("   ✅ Subscribed to order book")
            
            # Subscribe to trade executions
            await self.send_stomp_message("SUBSCRIBE", {
                "id": "trades-sub",
                "destination": "/topic/trades"
            })
            logger.info("   ✅ Subscribed to trades")
            
            # Subscribe to system messages
            await self.send_stomp_message("SUBSCRIBE", {
                "id": "system-sub",
                "destination": "/topic/system"
            })
            logger.info("   ✅ Subscribed to system messages")
            
        except Exception as e:
            logger.error(f"❌ Failed to subscribe to market data: {e}")
    
    def parse_stomp_message(self, message: str) -> Dict[str, Any]:
        """Parse a STOMP protocol message"""
        lines = message.split('\n')
        if not lines:
            return {}
        
        command = lines[0]
        headers = {}
        body_start = 1
        
        # Parse headers
        for i, line in enumerate(lines[1:], 1):
            if line == "":
                body_start = i + 1
                break
            if ":" in line:
                key, value = line.split(":", 1)
                headers[key] = value
        
        # Parse body
        body_lines = lines[body_start:]
        body = "\n".join(body_lines).rstrip('\x00')
        
        return {
            "command": command,
            "headers": headers,
            "body": body
        }
    
    def process_configuration(self, data: Dict[str, Any]):
        """Process configuration data"""
        try:
            if isinstance(data, dict):
                # Store portfolios
                portfolios = data.get('portfolios', [])
                self.portfolios = portfolios
                
                logger.info(f"📋 Configuration received:")
                logger.info(f"   Portfolios: {len(portfolios)}")
                
                for portfolio in portfolios[:3]:  # Show first 3
                    logger.info(f"     - {portfolio.get('id', 'Unknown')}: {portfolio.get('name', 'Unknown')}")
                    logger.info(f"       Permission: {portfolio.get('permission', 'Unknown')}")
                
                # Store contracts
                contracts = data.get('contracts', [])
                if contracts:
                    self.contracts = {c.get('id'): c for c in contracts}
                    logger.info(f"   Contracts: {len(contracts)}")
                    
                    # Show some active contracts
                    active_contracts = [c for c in contracts if c.get('status') == 'ACTIVE'][:5]
                    for contract in active_contracts:
                        logger.info(f"     - {contract.get('id', 'Unknown')}: {contract.get('deliveryStart', 'Unknown')}")
                
        except Exception as e:
            logger.error(f"Error processing configuration: {e}")
    
    def process_market_data(self, data: Dict[str, Any]):
        """Process market data updates"""
        try:
            contract_id = data.get('contractId', 'Unknown')
            bid_price = data.get('bidPrice')
            ask_price = data.get('askPrice')
            last_price = data.get('lastPrice')
            volume = data.get('volume', 0)
            
            logger.info(f"📊 Market Data - {contract_id}:")
            if bid_price is not None:
                logger.info(f"   Bid: €{bid_price:.2f}/MWh")
            if ask_price is not None:
                logger.info(f"   Ask: €{ask_price:.2f}/MWh")
            if last_price is not None:
                logger.info(f"   Last: €{last_price:.2f}/MWh")
            if volume > 0:
                logger.info(f"   Volume: {volume} MWh")
                
        except Exception as e:
            logger.error(f"Error processing market data: {e}")
    
    def process_trade(self, data: Dict[str, Any]):
        """Process trade executions"""
        try:
            contract_id = data.get('contractId', 'Unknown')
            price = data.get('price', 0)
            quantity = data.get('quantity', 0)
            timestamp = data.get('timestamp', datetime.now().isoformat())
            
            logger.info(f"💰 TRADE EXECUTED - {contract_id}:")
            logger.info(f"   Price: €{price:.2f}/MWh")
            logger.info(f"   Quantity: {quantity} MWh")
            logger.info(f"   Time: {timestamp}")
            
            # Store trade
            self.trades.append({
                'contractId': contract_id,
                'price': price,
                'quantity': quantity,
                'timestamp': timestamp
            })
            
            # Keep only last 100 trades
            if len(self.trades) > 100:
                self.trades = self.trades[-100:]
                
        except Exception as e:
            logger.error(f"Error processing trade: {e}")
    
    async def message_handler(self):
        """Handle incoming WebSocket messages"""
        try:
            async for msg in self.websocket:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    self.message_count += 1
                    self.last_update = datetime.now()
                    
                    message = msg.data
                    
                    # Parse STOMP message
                    parsed = self.parse_stomp_message(message)
                    command = parsed.get('command', '')
                    body = parsed.get('body', '')
                    
                    if command == 'CONNECTED':
                        logger.info("✅ STOMP connection established")
                        await self.subscribe_to_market_data()
                    
                    elif command == 'MESSAGE':
                        destination = parsed.get('headers', {}).get('destination', '')
                        
                        if body:
                            try:
                                data = json.loads(body)
                                
                                if 'configuration' in destination:
                                    self.process_configuration(data)
                                elif 'marketdata' in destination:
                                    self.process_market_data(data)
                                elif 'trades' in destination:
                                    self.process_trade(data)
                                else:
                                    logger.info(f"📨 Message from {destination}: {body[:200]}...")
                                    
                            except json.JSONDecodeError:
                                logger.info(f"📨 Non-JSON message: {body[:200]}...")
                    
                    elif command == 'ERROR':
                        logger.error(f"❌ STOMP Error: {body}")
                    
                    # Show periodic statistics
                    if self.message_count % 10 == 0:
                        logger.info(f"📊 Statistics: {self.message_count} messages received")
                        
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(f"❌ WebSocket error: {self.websocket.exception()}")
                    break
                    
                elif msg.type == aiohttp.WSMsgType.CLOSE:
                    logger.warning("⚠️ WebSocket connection closed")
                    break
                    
        except Exception as e:
            logger.error(f"❌ Error in message handler: {e}")
    
    async def start_viewing(self, duration_minutes: int = 5):
        """Start viewing real-time market data"""
        try:
            logger.info("🚀 Starting BRM Real-time Market Viewer")
            logger.info("=" * 60)
            
            # Connect to WebSocket
            if not await self.connect():
                return
            
            # Send STOMP CONNECT
            await self.send_stomp_message("CONNECT", {
                "accept-version": "1.0,1.1,1.2",
                "heart-beat": "10000,10000"
            })
            
            self.running = True
            
            # Start message handler
            handler_task = asyncio.create_task(self.message_handler())
            
            # Run for specified duration
            logger.info(f"📺 Viewing market data for {duration_minutes} minutes...")
            logger.info("   Press Ctrl+C to stop early")
            
            try:
                await asyncio.wait_for(handler_task, timeout=duration_minutes * 60)
            except asyncio.TimeoutError:
                logger.info(f"⏰ Viewing session completed ({duration_minutes} minutes)")
            
        except KeyboardInterrupt:
            logger.info("⏹️ Stopped by user")
        except Exception as e:
            logger.error(f"❌ Error during viewing: {e}")
        finally:
            await self.stop()
    
    async def stop(self):
        """Stop the market viewer"""
        logger.info("🛑 Stopping market viewer...")
        self.running = False
        
        if self.websocket:
            try:
                await self.send_stomp_message("DISCONNECT")
                await self.websocket.close()
            except:
                pass
        
        if self.session:
            await self.session.close()
        
        # Show final statistics
        logger.info("📊 Final Statistics:")
        logger.info(f"   Messages received: {self.message_count}")
        logger.info(f"   Portfolios: {len(self.portfolios)}")
        logger.info(f"   Contracts: {len(self.contracts)}")
        logger.info(f"   Trades seen: {len(self.trades)}")
        logger.info(f"   Last update: {self.last_update}")
        
        if self.trades:
            logger.info("💰 Recent Trades:")
            for trade in self.trades[-5:]:  # Show last 5 trades
                logger.info(f"   {trade['contractId']}: {trade['quantity']} MWh @ €{trade['price']:.2f}/MWh")


async def test_simple_connection():
    """Test a simple connection to see what happens"""
    logger.info("🧪 Testing simple WebSocket connection...")
    
    try:
        auth = initialize_working_auth()
        token_info = await auth.get_token_async()
        
        logger.info(f"✅ Token: {token_info.access_token[:50]}...")
        
        # Try connecting to the WebSocket URL
        ws_url = "wss://intraday-pmd-api-ws-brm.test.nordpoolgroup.com/"
        
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        
        headers = {
            "Authorization": token_info.bearer_token,
            "User-Agent": "BRM-Trading-Bot/1.0"
        }
        
        async with aiohttp.ClientSession() as session:
            logger.info(f"🌐 Attempting connection to {ws_url}")
            
            try:
                async with session.ws_connect(
                    ws_url,
                    headers=headers,
                    ssl=ssl_context,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as ws:
                    logger.info("✅ WebSocket connection successful!")
                    
                    # Send STOMP CONNECT
                    connect_msg = "CONNECT\naccept-version:1.0,1.1,1.2\nheart-beat:10000,10000\n\n\x00"
                    await ws.send_str(connect_msg)
                    logger.info("📤 Sent STOMP CONNECT message")
                    
                    # Wait for response
                    try:
                        msg = await asyncio.wait_for(ws.receive(), timeout=10)
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            logger.info(f"📥 Received: {msg.data[:200]}...")
                            
                            # If we get CONNECTED, try subscribing
                            if "CONNECTED" in msg.data:
                                logger.info("✅ STOMP connection established!")
                                
                                # Subscribe to configuration
                                sub_msg = "SUBSCRIBE\nid:config-sub\ndestination:/user/queue/configuration\n\n\x00"
                                await ws.send_str(sub_msg)
                                logger.info("📤 Subscribed to configuration")
                                
                                # Wait for more messages
                                for i in range(5):
                                    try:
                                        msg = await asyncio.wait_for(ws.receive(), timeout=5)
                                        if msg.type == aiohttp.WSMsgType.TEXT:
                                            logger.info(f"📥 Message {i+1}: {msg.data[:200]}...")
                                    except asyncio.TimeoutError:
                                        logger.info(f"⏰ Timeout waiting for message {i+1}")
                                        break
                        
                    except asyncio.TimeoutError:
                        logger.warning("⏰ Timeout waiting for STOMP response")
                        
            except Exception as e:
                logger.error(f"❌ WebSocket connection failed: {e}")
                logger.error(f"   Error type: {type(e).__name__}")
                
    except Exception as e:
        logger.error(f"❌ Test failed: {e}")


async def main():
    """Main function"""
    logger.info("🇷🇴 BRM REAL-TIME INTRADAY MARKET VIEWER - FIXED")
    logger.info("=" * 60)
    logger.info("Connecting to live Romanian energy market data...")
    logger.info("=" * 60)
    
    # First, test simple connection
    await test_simple_connection()
    
    logger.info("\n" + "=" * 60)
    logger.info("Now starting full market viewer...")
    logger.info("=" * 60)
    
    viewer = BRMMarketViewerFixed()
    
    try:
        # View market for 3 minutes
        await viewer.start_viewing(duration_minutes=3)
        
    except Exception as e:
        logger.error(f"❌ Viewer failed: {e}")
    
    logger.info("🎬 Market viewing session ended")


if __name__ == "__main__":
    # Set test environment
    os.environ["BRM_ENVIRONMENT"] = "test"
    
    # Run the viewer
    asyncio.run(main())
