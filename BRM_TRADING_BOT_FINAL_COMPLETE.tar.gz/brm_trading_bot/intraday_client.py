"""
Intraday Market WebSocket Client for BRM Trading Bot
Handles STOMP protocol WebSocket connections for real-time trading
"""
import asyncio
import json
import logging
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, Callable, List
from dataclasses import dataclass
from enum import Enum

import websockets
from websockets.exceptions import ConnectionClosed, WebSocketException

from auth import get_authenticator
from config import config


class OrderType(Enum):
    """Intraday order types"""
    LIMIT = "LIMIT"
    ICEBERG = "ICEBERG"
    USER_DEFINED_BLOCK = "USER_DEFINED_BLOCK"


class TimeInForce(Enum):
    """Time in force options"""
    FOK = "FOK"  # Fill or Kill
    IOC = "IOC"  # Immediate or Cancel
    GFS = "GFS"  # Good for Session
    GTD = "GTD"  # Good Till Date


class ExecutionRestriction(Enum):
    """Execution restriction options"""
    AON = "AON"  # All or None
    NON = "NON"  # No restrictions


class OrderModificationType(Enum):
    """Order modification types"""
    ACTIVATE = "ACTI"
    DEACTIVATE = "DEAC"
    MODIFY = "MODI"
    DELETE = "DELE"


@dataclass
class IntradayOrder:
    """Intraday order structure"""
    portfolio_id: str
    contract_ids: List[str]
    delivery_area_id: int
    side: str  # "BUY" or "SELL"
    order_type: OrderType
    unit_price: int  # Price in cents
    quantity: int  # Quantity in kW
    time_in_force: TimeInForce
    execution_restriction: ExecutionRestriction
    state: str = "ACTI"
    client_order_id: Optional[str] = None
    clip_size: Optional[int] = None
    clip_price_change: Optional[int] = None
    expire_time: Optional[str] = None
    text: Optional[str] = None
    
    def __post_init__(self):
        if self.client_order_id is None:
            self.client_order_id = str(uuid.uuid4())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API request"""
        order_dict = {
            "portfolioId": self.portfolio_id,
            "contractIds": self.contract_ids,
            "deliveryAreaId": self.delivery_area_id,
            "side": self.side,
            "orderType": self.order_type.value,
            "unitPrice": self.unit_price,
            "quantity": self.quantity,
            "timeInForce": self.time_in_force.value,
            "executionRestriction": self.execution_restriction.value,
            "state": self.state,
            "clientOrderId": self.client_order_id
        }
        
        # Add optional fields if present
        if self.clip_size is not None:
            order_dict["clipSize"] = self.clip_size
        if self.clip_price_change is not None:
            order_dict["clipPriceChange"] = self.clip_price_change
        if self.expire_time is not None:
            order_dict["expireTime"] = self.expire_time
        if self.text is not None:
            order_dict["text"] = self.text
        
        return order_dict


class STOMPFrame:
    """STOMP protocol frame"""
    
    def __init__(self, command: str, headers: Dict[str, str] = None, body: str = ""):
        self.command = command
        self.headers = headers or {}
        self.body = body
    
    def to_string(self) -> str:
        """Convert frame to STOMP protocol string"""
        frame_str = self.command + "\n"
        
        for key, value in self.headers.items():
            frame_str += f"{key}:{value}\n"
        
        frame_str += "\n" + self.body + "\x00"
        return frame_str
    
    @classmethod
    def from_string(cls, frame_str: str) -> 'STOMPFrame':
        """Parse STOMP frame from string"""
        lines = frame_str.split('\n')
        command = lines[0]
        
        headers = {}
        body_start = 1
        
        for i, line in enumerate(lines[1:], 1):
            if line == "":
                body_start = i + 1
                break
            if ":" in line:
                key, value = line.split(":", 1)
                headers[key] = value
        
        body = "\n".join(lines[body_start:]).rstrip('\x00')
        return cls(command, headers, body)


class IntradayWebSocketClient:
    """WebSocket client for Intraday market using STOMP protocol"""
    
    def __init__(self, username: str):
        self.username = username
        self.websocket: Optional[websockets.WebSocketServerProtocol] = None
        self.connected = False
        self.subscriptions: Dict[str, str] = {}  # topic -> subscription_id
        self.message_handlers: Dict[str, Callable] = {}
        self.logger = logging.getLogger(__name__)
        self.heartbeat_task: Optional[asyncio.Task] = None
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = config.max_reconnection_attempts
    
    async def connect(self) -> bool:
        """
        Connect to the WebSocket server and perform STOMP handshake
        """
        try:
            auth = get_authenticator()
            token_info = await auth.get_token_async()
            
            self.logger.info(f"Connecting to {config.websocket_url}")
            
            self.websocket = await websockets.connect(
                config.websocket_url,
                subprotocols=["v12.stomp"]
            )
            
            # Send CONNECT frame
            connect_frame = STOMPFrame(
                "CONNECT",
                {
                    "accept-version": "1.2",
                    "host": config.websocket_url.split("//")[1].split("/")[0],
                    "X-AUTH-TOKEN": token_info.access_token,
                    "heart-beat": "0,15000"  # Client heartbeat every 15 seconds
                }
            )
            
            await self.websocket.send(connect_frame.to_string())
            
            # Wait for CONNECTED frame
            response = await self.websocket.recv()
            response_frame = STOMPFrame.from_string(response)
            
            if response_frame.command == "CONNECTED":
                self.connected = True
                self.reconnect_attempts = 0
                self.logger.info("Successfully connected to Intraday WebSocket")
                
                # Start heartbeat task
                self.heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                
                # Start message listening task
                asyncio.create_task(self._listen_for_messages())
                
                return True
            else:
                self.logger.error(f"Connection failed: {response_frame.body}")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to connect: {e}")
            return False
    
    async def disconnect(self):
        """Disconnect from the WebSocket server"""
        if self.connected and self.websocket:
            try:
                # Send DISCONNECT frame
                disconnect_frame = STOMPFrame("DISCONNECT")
                await self.websocket.send(disconnect_frame.to_string())
                
                # Cancel heartbeat task
                if self.heartbeat_task:
                    self.heartbeat_task.cancel()
                
                await self.websocket.close()
                self.connected = False
                self.logger.info("Disconnected from Intraday WebSocket")
                
            except Exception as e:
                self.logger.error(f"Error during disconnect: {e}")
    
    async def subscribe(self, topic: str, handler: Callable[[Dict[str, Any]], None]) -> str:
        """
        Subscribe to a topic and register a message handler
        
        Args:
            topic: The topic to subscribe to
            handler: Function to handle incoming messages
            
        Returns:
            Subscription ID
        """
        if not self.connected:
            raise ConnectionError("Not connected to WebSocket")
        
        subscription_id = str(uuid.uuid4())
        
        subscribe_frame = STOMPFrame(
            "SUBSCRIBE",
            {
                "id": subscription_id,
                "destination": topic,
                "ack": "auto"
            }
        )
        
        await self.websocket.send(subscribe_frame.to_string())
        
        self.subscriptions[topic] = subscription_id
        self.message_handlers[subscription_id] = handler
        
        self.logger.info(f"Subscribed to {topic} with ID {subscription_id}")
        return subscription_id
    
    async def unsubscribe(self, topic: str):
        """Unsubscribe from a topic"""
        if topic not in self.subscriptions:
            return
        
        subscription_id = self.subscriptions[topic]
        
        unsubscribe_frame = STOMPFrame(
            "UNSUBSCRIBE",
            {"id": subscription_id}
        )
        
        await self.websocket.send(unsubscribe_frame.to_string())
        
        del self.subscriptions[topic]
        del self.message_handlers[subscription_id]
        
        self.logger.info(f"Unsubscribed from {topic}")
    
    async def send_order(self, order: IntradayOrder, reject_partially: bool = False) -> str:
        """
        Send an order to the market
        
        Args:
            order: The order to send
            reject_partially: Whether to reject partially if there are errors
            
        Returns:
            Request ID
        """
        if not self.connected:
            raise ConnectionError("Not connected to WebSocket")
        
        request_id = str(uuid.uuid4())
        
        order_request = {
            "requestId": request_id,
            "rejectPartially": reject_partially,
            "linkedBasket": False,
            "orders": [order.to_dict()]
        }
        
        send_frame = STOMPFrame(
            "SEND",
            {
                "destination": f"/{config.api_version}/orderEntryRequest",
                "content-type": "application/json"
            },
            json.dumps(order_request)
        )
        
        await self.websocket.send(send_frame.to_string())
        
        self.logger.info(f"Sent order {order.client_order_id} with request ID {request_id}")
        return request_id
    
    async def modify_order(
        self, 
        order_id: str, 
        modification_type: OrderModificationType,
        modifications: Optional[Dict[str, Any]] = None,
        revision_no: int = 1
    ) -> str:
        """
        Modify an existing order
        
        Args:
            order_id: The order ID to modify
            modification_type: Type of modification
            modifications: Dictionary of fields to modify
            revision_no: Revision number for the modification
            
        Returns:
            Request ID
        """
        if not self.connected:
            raise ConnectionError("Not connected to WebSocket")
        
        request_id = str(uuid.uuid4())
        
        modification_request = {
            "requestId": request_id,
            "orders": [{
                "orderId": order_id,
                "orderModificationType": modification_type.value,
                "revisionNo": revision_no,
                **(modifications or {})
            }]
        }
        
        send_frame = STOMPFrame(
            "SEND",
            {
                "destination": f"/{config.api_version}/orderModificationRequest",
                "content-type": "application/json"
            },
            json.dumps(modification_request)
        )
        
        await self.websocket.send(send_frame.to_string())
        
        self.logger.info(f"Sent modification for order {order_id} with request ID {request_id}")
        return request_id
    
    async def refresh_token(self, new_token: str, old_token: str):
        """
        Refresh the authentication token
        
        Args:
            new_token: The new authentication token
            old_token: The old authentication token
        """
        if not self.connected:
            raise ConnectionError("Not connected to WebSocket")
        
        token_refresh = {
            "type": "TOKEN_REFRESH",
            "oldToken": old_token,
            "newToken": new_token
        }
        
        send_frame = STOMPFrame(
            "SEND",
            {
                "destination": f"/{config.api_version}/command",
                "content-type": "application/json"
            },
            json.dumps(token_refresh)
        )
        
        await self.websocket.send(send_frame.to_string())
        self.logger.info("Token refresh request sent")
    
    async def _heartbeat_loop(self):
        """Send heartbeat messages to keep connection alive"""
        try:
            while self.connected:
                await asyncio.sleep(config.websocket_heartbeat_interval)
                if self.connected and self.websocket:
                    await self.websocket.ping()
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.logger.error(f"Heartbeat error: {e}")
    
    async def _listen_for_messages(self):
        """Listen for incoming messages and dispatch to handlers"""
        try:
            while self.connected and self.websocket:
                try:
                    message = await self.websocket.recv()
                    frame = STOMPFrame.from_string(message)
                    
                    if frame.command == "MESSAGE":
                        subscription_id = frame.headers.get("subscription")
                        if subscription_id in self.message_handlers:
                            try:
                                if frame.body:
                                    data = json.loads(frame.body)
                                    await self._safe_call_handler(
                                        self.message_handlers[subscription_id], 
                                        data
                                    )
                            except json.JSONDecodeError as e:
                                self.logger.error(f"Failed to parse message JSON: {e}")
                    
                    elif frame.command == "ERROR":
                        self.logger.error(f"STOMP error: {frame.body}")
                    
                except ConnectionClosed:
                    self.logger.warning("WebSocket connection closed")
                    self.connected = False
                    await self._attempt_reconnect()
                    break
                    
        except Exception as e:
            self.logger.error(f"Message listening error: {e}")
            self.connected = False
    
    async def _safe_call_handler(self, handler: Callable, data: Dict[str, Any]):
        """Safely call a message handler"""
        try:
            if asyncio.iscoroutinefunction(handler):
                await handler(data)
            else:
                handler(data)
        except Exception as e:
            self.logger.error(f"Error in message handler: {e}")
    
    async def _attempt_reconnect(self):
        """Attempt to reconnect to the WebSocket"""
        if self.reconnect_attempts >= self.max_reconnect_attempts:
            self.logger.error("Max reconnection attempts reached")
            return
        
        self.reconnect_attempts += 1
        wait_time = min(2 ** self.reconnect_attempts, 60)  # Exponential backoff, max 60s
        
        self.logger.info(f"Attempting reconnection {self.reconnect_attempts}/{self.max_reconnect_attempts} in {wait_time}s")
        await asyncio.sleep(wait_time)
        
        if await self.connect():
            # Re-subscribe to all previous topics
            for topic, subscription_id in list(self.subscriptions.items()):
                handler = self.message_handlers.get(subscription_id)
                if handler:
                    await self.subscribe(topic, handler)
    
    async def subscribe_to_configuration(self, handler: Callable[[Dict[str, Any]], None]) -> str:
        """Subscribe to configuration updates"""
        topic = f"/user/{self.username}/{config.api_version}/configuration"
        return await self.subscribe(topic, handler)
    
    async def subscribe_to_order_execution_reports(self, handler: Callable[[Dict[str, Any]], None]) -> str:
        """Subscribe to order execution reports"""
        topic = f"/user/{self.username}/{config.api_version}/streaming/orderExecutionReport"
        return await self.subscribe(topic, handler)
    
    async def subscribe_to_private_trades(self, handler: Callable[[Dict[str, Any]], None]) -> str:
        """Subscribe to private trade updates"""
        topic = f"/user/{self.username}/{config.api_version}/streaming/privateTrade"
        return await self.subscribe(topic, handler)
    
    async def subscribe_to_local_view(self, area_id: int, handler: Callable[[Dict[str, Any]], None]) -> str:
        """Subscribe to local market view for a specific area"""
        topic = f"/user/{self.username}/{config.api_version}/streaming/localview/{area_id}"
        return await self.subscribe(topic, handler)
